<?php

define('AJAX_SCRIPT', true);
require('../../config.php');
global $CFG,$DB,$USER,$PAGE,$OUTPUT;
require_once($CFG->dirroot.'/course/lib.php');

$output = '';
$url_components = parse_url($_SERVER['HTTP_REFERER']);
parse_str($url_components['query'], $params);
$course = $DB->get_record('course',array('id'=>$params['id']));

$modinfo = get_fast_modinfo($course);
$modfullnames = array();

$archetypes = array();

foreach($modinfo->cms as $cm) {
    // Exclude activities which are not visible or have no link (=label)
    if (!$cm->uservisible or !$cm->has_view()) {
        continue;
    }

    if (!array_key_exists($cm->modname, $archetypes)) {
        $archetypes[$cm->modname] = plugin_supports('mod', $cm->modname, FEATURE_MOD_ARCHETYPE, MOD_ARCHETYPE_OTHER);
    }
    $cmrecord = $DB->get_record('course_modules',array('id'=>$cm->id));
    $dateadded = userdate($cmrecord->added, get_string('strftimedate', 'langconfig'));


    $count = $DB->get_record_sql("SELECT COUNT(id) as count FROM mdl_logstore_standard_log 
                                                            WHERE `eventname` LIKE '%course_module_viewed%' 
                                                                AND target='course_module' AND action='viewed'
                                                                AND contextinstanceid=$cm->id AND userid=$USER->id");
    if ($archetypes[$cm->modname] == MOD_ARCHETYPE_RESOURCE) {
        if (!array_key_exists('resources', $modfullnames)) {
            $modfullnames['resources'] = get_string('resources');
            $icon = $OUTPUT->pix_icon('icon', '', 'mod_page', array('class' => 'icon'));
            $output .=  $cm->id.' - <a href="'.$CFG->wwwroot.'/mod/'.$cm->modname.'/view.php?id='.$cm->id.'">'.$icon.$cm->name.'</a> - '.$dateadded. ' - '.$count->count;
        }
    } else {
        $modfullnames[$cm->modname] = $cm->modplural;
        $icon = $OUTPUT->image_icon('icon', get_string('pluginname', $cm->modname), $cm->modname);
        $output .= $cm->id.' - <a href="'.$CFG->wwwroot.'/mod/'.$cm->modname.'/view.php?id='.$cm->id.'">'.$icon.$cm->name.'</a> - '.$dateadded. ' - '.$count->count;

    }
    $output .= "<br/>";

}

if (!empty($output)) {
    echo json_encode($output);
} else {
    echo json_encode("<div class = 'alert alert-success'>No Activites.</div>");
}

