$(window).on("load", function() {
        $.ajax({
            type: "GET",
            url:  M.cfg.wwwroot +'/blocks/activity_modules/ajax.php',
            beforeSend: function (){
                $('.block_activity_modules .content').addClass('loader').append('<div class="fa-loader" style="text-align: center;margin-top:10px;"><img src="'+M.cfg.wwwroot +'/pix/y/loading.gif"></div>');
            },
            success : function(html){
                $('.block_activity_modules .content').html(html);
            }
        });
});